import { queryBasicList } from '../services/personinformation';

export default {
	namespace: 'personinformation',

	state: {
		data: {
			list: [],
			pagination: {},
		},
	},

	effects: {
		*fetch({ payload }, { call, put }) {
			const response = yield call(queryBasicList, payload);
			yield put({
				type: 'save',
				payload: response,
			});
		},
		// *add({ payload, callback }, { call, put }) {
		//   const response = yield call(addRule, payload);
		//   yield put({
		//     type: 'save',
		//     payload: response,
		//   });
		//   if (callback) callback();
		// },
		// *remove({ payload, callback }, { call, put }) {
		//   const response = yield call(removeRule, payload);
		//   yield put({
		//     type: 'save',
		//     payload: response,
		//   });
		//   if (callback) callback();
		// },
	},

	reducers: {
		save(state, action) {
			let d = action.payload;

			if (d === undefined) {
				d = {
					list: [],
				};
			}

			const { status } = d;

			if (status === 200) {
				for (const o of d.list) {
					o.key = o.personnelId;
				}

				d.pagination = {
					total: d.total,
					pageSize: d.pageSize,
					current: parseInt(d.pageNo, 10) || 1,
				};
			} else {
				d.pagination = {
					total: 0,
					pageSize: 10,
					current: 1,
				};
			}
			return {
				...state,
				data: d,
			};
		},
	},
};
