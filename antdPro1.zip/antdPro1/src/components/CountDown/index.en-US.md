---
title: CountDown
cols: 1
order: 3
---

Simple CountDown Component.

## API

| Property | Description | Type | Default |
|----------|------------------------------------------|-------------|-------|
| format | Formatter of time | Function(time) |  |
| target | Target time | Date | - |
| onEnd |  Countdown to the end callback | funtion | -|
