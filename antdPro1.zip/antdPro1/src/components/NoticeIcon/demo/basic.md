---
order: 1
title: 通知图标
---

通常用在导航工具栏上。

````jsx
import NoticeIcon from 'ant-design-pro/lib/NoticeIcon';

ReactDOM.render(<NoticeIcon count={5} />, mountNode);
````
